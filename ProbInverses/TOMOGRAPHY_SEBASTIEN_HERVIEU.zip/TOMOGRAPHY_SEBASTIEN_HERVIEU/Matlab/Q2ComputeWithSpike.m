clear; close all;

performComputeSpike(7,7, [0 0.1 0.5 1]);
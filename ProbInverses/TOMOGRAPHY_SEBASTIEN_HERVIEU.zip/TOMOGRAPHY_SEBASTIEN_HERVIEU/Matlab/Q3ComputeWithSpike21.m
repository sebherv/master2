clear all;

performComputeSpike(21,21,[0 0.1 0.5 1]);
clear all;

performComputeSpike(11,11, [0 0.1 0.5 1]);
clear all;

performComputeSpike(15,15, [0 0.1 0.5 1]);
Pour compiler le programme monothread:

> g++ -fopenmp histogramSingleThread.cpp -o singleThread

Pour exécuter le programme mono thread:

> ./singleThread



Pour compiler le programme multithread avec la directive "atomic"

> g++ -fopenmp histogramAtomic.cpp -o histoAtomic

Pour exécuter le programme multithread avec la directive "atomic"

> ./histoAtomic


Pour compiler le programme multithread final, avec histogrammes privés pour chaque threads

> g++ -fopenmp histogram.cpp -o histogram

Pour exécuter:

> ./histogram
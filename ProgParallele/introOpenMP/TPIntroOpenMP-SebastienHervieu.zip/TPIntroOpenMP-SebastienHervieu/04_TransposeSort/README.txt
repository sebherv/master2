Pour compiler le programme avec schedule(static):

> g++ -fopenmp transposeSort-static.cpp -o transposeSort-static

Pour exécuter

> ./transposeSort-static


Pour compiler le programme avec schedule(dynamic):

> g++ -fopenmp transposeSort-dynamic.cpp -o transposeSort-dynamic

Pour exécuter

> ./transposeSort-dynamic

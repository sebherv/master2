Pour compiler:

> g++ -fopenmp is_prime.cpp

Pour exécuter:

> ./a.out [nombre entier]
Pour compiler le programme original:
> g++ -fopenmp md.cpp -o mdSingle

Pour exécuter le programme original:
> ./mdSingle


Pour compiler le programme parallèlisé:
> g++ -fopenmp mdparallelized.cpp - mdparallelized

Pour exécuter le programme parallèlisé:
./mdparallelized
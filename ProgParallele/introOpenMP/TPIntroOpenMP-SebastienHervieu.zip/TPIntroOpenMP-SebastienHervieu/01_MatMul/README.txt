Pour compiler:

> g++ -fopenmp *.cpp

Pour exécuter:

> ./a.out